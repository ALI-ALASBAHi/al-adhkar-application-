package com.example.adkhar_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
