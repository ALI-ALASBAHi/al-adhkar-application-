import 'package:flutter/material.dart';

class BackupSyncScreen extends StatelessWidget {
  const BackupSyncScreen({super.key});
  @override
  Widget build(BuildContext context) => const Center(child: Text('Backup & Sync'));
}


