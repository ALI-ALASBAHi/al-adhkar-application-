import 'package:flutter/material.dart';

class DhikrReaderScreen extends StatelessWidget {
  const DhikrReaderScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(child: Text('Dhikr Reader'));
  }
}


