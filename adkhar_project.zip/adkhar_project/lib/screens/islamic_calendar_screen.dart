import 'package:flutter/material.dart';

class IslamicCalendarScreen extends StatelessWidget {
  const IslamicCalendarScreen({super.key});
  @override
  Widget build(BuildContext context) => const Center(child: Text('Islamic Calendar'));
}


